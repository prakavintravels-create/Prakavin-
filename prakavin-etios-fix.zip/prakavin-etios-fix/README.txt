PRAKAVIN TRAVELS - ETIOS IMAGE UPDATE

1. Upload public/etios.png into the public folder in your GitHub project.
2. In styles.css, find the existing .etios-image rule and replace only its background-image URL with:

.etios-image {
  background-image: url('/etios.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

Keep the existing .car-image rule and the .innova-image rule unchanged.
3. Commit the changes in GitHub and wait for Vercel to redeploy.
